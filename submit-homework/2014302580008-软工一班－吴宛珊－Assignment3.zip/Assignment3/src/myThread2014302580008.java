import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class myThread2014302580008 extends Thread {
	private LinkedList<String> urls;
    public class CrawlRunnable implements Runnable{
    	
    	private String url;
        CrawlRunnable(String u){
        	
        	url = u;
        }
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ImagineCrawler2014302580008 crawlerInfo = new ImagineCrawler2014302580008();
			
			try {
				crawlerInfo.getInfoFromTeacher(url);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    	
    }
    //单线程爬取
    public void getInfoBySingleThread() throws IOException, SQLException {
    	ImagineCrawler2014302580008.createConnection();
		ImagineCrawler2014302580008 crawlerURLs = new ImagineCrawler2014302580008();
		
		urls = crawlerURLs.getURLsFromTeachers();
		
		ImagineCrawler2014302580008 crawInf = new ImagineCrawler2014302580008();
		Iterator<String> it = urls.iterator();//迭代器循环
		while(it.hasNext()){
			
			crawInf.getInfoFromTeacher(it.next());//存在下一向则继续循环

			
		}
	}
    //多线程爬取
    public void getInfoByMultiThread() throws IOException{
    	ImagineCrawler2014302580008.createConnection();
		ExecutorService exec = Executors.newFixedThreadPool(5); //创建线程池  
		ImagineCrawler2014302580008 crawlerURLs = new ImagineCrawler2014302580008();
		urls = crawlerURLs.getURLsFromTeachers();
		Iterator<String> it = urls.iterator();//迭代器循环
		while(it.hasNext()){
			String s = it.next();
			CrawlRunnable c = new CrawlRunnable(s);
			exec.execute(new Thread(c));
		}
		exec.shutdown();
	}
	 
}
