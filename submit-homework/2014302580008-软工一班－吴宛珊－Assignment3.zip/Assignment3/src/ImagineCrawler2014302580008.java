import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
//爬取教师信息
public class ImagineCrawler2014302580008 { 
	public ImagineCrawler2014302580008(){
		
	}
	
	private String html = "http://www.wpi.edu/academics/cs/research-interests.html";//爬取网页的URL
	static private Connection con;
	public LinkedList<String> getURLsFromTeachers() throws IOException{
		LinkedList<String> urls = new LinkedList<String>();//将获取到的教师URL存入链表
		Document doc = Jsoup.connect(html).get();
		Element half = doc.select("div.half").first();
		
		Elements ed = half.select("a");
		for(Element e:ed){
			String url = e.attr("href");
			if(!urls.contains(url)){
				urls.add(e.attr("href"));
			}
			
		}
		return urls; //获取每个老师的URL
	}
	 public void getInfoFromTeacher(String url) throws IOException{
		 String[] inf = new String[5];//建立数组用于存储姓名，电话号码，邮箱，简介，研究领域等
		 for(int i = 0; i < inf.length; ++i){
			 inf[i] = "";
		 }
		 Pattern email = Pattern.compile("[a-zA-Z]+[a-zA-Z0-9\\_]*\\@([a-zA-Z]+\\.)+[a-zA-Z0-9]+");//正则表达式提取邮箱
		 Pattern tel = Pattern.compile("\\+[0-9]{1}\\-[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}");//正则表达式提取电话号码
		 Document doc = null;
		 try{
			doc = Jsoup.connect(url).get();
		}
		catch(org.jsoup.HttpStatusException e){
			return;
		}
		 catch(java.net.SocketTimeoutException e){
			 try{
				 doc = Jsoup.connect(url).get();
			 }
			 catch(Exception exc){
				 return;
			 }
		 }
		Element content = doc.select("#content").first();
		try{
			Element breif = content.select("p").get(3);//获取简介
			inf[3] = breif.text();
		}
		catch(java.lang.IndexOutOfBoundsException e){
			inf[3] = "";
		}
	    Elements fields = content.select("#twocol").select("div.col").select("li");//获取研究领域
		Element contactInfo = content.select("#contactinfo").first();
		inf[0] = content.select("h2").first().text();//教师姓名

		for(Element e:fields){
			inf[4] += e.text()+" ";//研究领域
		}
		 
		                  
			String s = contactInfo.text();
			Matcher tel_matcher = tel.matcher(s);//电话号码匹配
			Matcher email_matcher = email.matcher(s);//邮箱匹配
				if(tel_matcher.find())                                
				{
					inf[1] += tel_matcher.group(0);
				} 
				if (email_matcher.find()) {                      
					inf[2] += email_matcher.group(0);
				}
			
			for(int i=0;i<inf.length;i++){
				System.out.println(inf[i]);
			}
		 
		 toDataBase(inf);//调用函数，信息写入数据库
	 }
	 //数据库
	 public void toDataBase(String[] information){
		 
		 try{
			 Statement stmt = con.createStatement();//命令行接口
			 
			 for(int i = 0; i < information.length; ++i){
				information[i] = information[i].replace("\'", "\\\'"); 
			 }
			 String sql = "insert into teachers(name,tel,mail,breif,field) values('" + information[0]+"','"+information[1]+"','"+information[2]+"','"+information[3]+"','"+information[4]+"');";
	         stmt.executeUpdate(sql);
	         
		 	}catch (SQLException e) {
	            System.out.println("error");
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } 
	 }
	 static public void createConnection(){
		 
		 String url = "jdbc:mysql://127.0.0.1:3306/teacher?user=root&password=123456";
		 
		 try{
			 Class.forName("com.mysql.jdbc.Driver");
			 con = DriverManager.getConnection(url);
			 String sql = "drop table if exists teachers;";
			 Statement stmt = con.createStatement();
			 stmt.execute(sql);
			 sql = "create table teachers(name varchar(50), tel varchar(50), mail varchar(50), breif varchar(10000), field varchar(500));";
	         stmt.execute(sql);
		 }
     catch (Exception e) {
         System.out.println("error");
         e.printStackTrace();
     } 
	 }
	

}
