import java.io.IOException;
import java.sql.SQLException;
public class main2014302580008 {
	public static void main(String[] args) throws IOException, SQLException {
		// TODO Auto-generated method stub	
		
		myThread2014302580008 testSingle = new myThread2014302580008();
		System.out.println("单线程爬取中");
		long singlebegintime = System.currentTimeMillis();
		testSingle.getInfoBySingleThread();
		long singleendtime = System.currentTimeMillis();
		System.out.println("单线程时间为"+(singleendtime - singlebegintime)+"ms");
		
		myThread2014302580008 testMulti = new myThread2014302580008();
		System.out.println("多线程爬取中");
		long multibegintime = System.currentTimeMillis();
		testMulti.getInfoByMultiThread();
		while(true){
			if(Thread.activeCount() < 3 )
				break;
		}
		long multiendtime = System.currentTimeMillis();
		System.out.println("多线程时间为"+(multiendtime - multibegintime)+"ms");
	}
}


